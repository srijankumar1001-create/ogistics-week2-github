"""Before/after data-quality comparison.

Re-runs the audit from data_quality_audit.py on the raw extract and on the
cleaned output of cleaning_pipeline.py (+ outlier treatment), then prints
the side-by-side comparison table used in Section 11 of the Week 2 report.

The table is a computed artifact of the pipeline — never hand-edited —
so the improvement claim is reproducible.

Runnable as-is.
"""

import pandas as pd

from data_quality_audit import make_synthetic_raw, audit_dataframe
from cleaning_pipeline import cleaning_pipeline
from outlier_detection import treat_outliers


def quality_metrics(df):
    """Compute the headline quality metrics for one dataset snapshot."""
    # Quarantined rows are excluded from modeling-data violation counts:
    # they are retained with a flag for ops review, not fed to models.
    q = df.get("parcel_weight_kg_quarantined", 0)
    if not isinstance(q, pd.Series):
        q = pd.Series(0, index=df.index)
    over_cap = ((df["parcel_weight_kg"] > 500) & (q.fillna(0) == 0)).sum()
    return {
        "rows": len(df),
        "duplicate_order_ids": int(df.duplicated(subset="order_id").sum()),
        "missing_weight_pct": df["parcel_weight_kg"].isna().mean() * 100,
        "sentinel_weights": int((df["parcel_weight_kg"] == -1).sum()),
        "invalid_geocodes": int((df["delivery_lat"] == 0.0).sum()),
        "zone_case_variants": (
            df["customer_zone"].astype(str).nunique()
            - df["customer_zone"].astype(str).str.strip().str.upper().nunique()
        ),
        "over_capacity_parcels": int(over_cap),
    }


def median_impute_weight(df):
    """Median imputation of weight within carrier mode + missingness flag."""
    df = df.copy()
    df["weight_imputed"] = df["parcel_weight_kg"].isna().astype(int)
    df["parcel_weight_kg"] = df.groupby("carrier_mode")[
        "parcel_weight_kg"].transform(lambda s: s.fillna(s.median()))
    n = int(df["weight_imputed"].sum())
    print(f"[impute] median weight imputation within carrier_mode: "
          f"{n} value(s) (flagged in weight_imputed)")
    return df


if __name__ == "__main__":
    raw = make_synthetic_raw()
    clean = cleaning_pipeline(raw)
    clean = treat_outliers(clean, "parcel_weight_kg",
                           impossible_mask=clean["parcel_weight_kg"] > 500)
    clean = median_impute_weight(clean)  # documented missing-value rule

    before, after = quality_metrics(raw), quality_metrics(clean)
    rows = [
        ("Total rows", f"{before['rows']:,}", f"{after['rows']:,}",
         "duplicates removed (logged)"),
        ("Duplicate order_id rows", before["duplicate_order_ids"],
         after["duplicate_order_ids"], "deduplicated on business key"),
        ("Missing parcel_weight_kg (%)",
         f"{before['missing_weight_pct']:.1f}%",
         f"{after['missing_weight_pct']:.1f}%",
         "sentinels -> missing, then median imputation + flag"),
        ("Sentinel weights (-1)", before["sentinel_weights"],
         after["sentinel_weights"], "converted to proper missing"),
        ("Invalid geocodes (0.0 lat)", before["invalid_geocodes"],
         after["invalid_geocodes"], "invalidated -> zone-centroid fallback"),
        ("Zone label case variants", before["zone_case_variants"],
         after["zone_case_variants"], "canonical mapping dictionary"),
        ("Over-capacity parcels in modeling data",
         before["over_capacity_parcels"], after["over_capacity_parcels"],
         "quarantined with flag; excluded from model inputs"),
    ]
    table = pd.DataFrame(rows, columns=[
        "Quality metric", "Before (raw)", "After (cleaned)", "Resolution"])
    print("\nBEFORE / AFTER DATA QUALITY COMPARISON")
    print(table.to_string(index=False))

    # Full audit pass on the cleaned data proves zero residual defects
    audit_dataframe(
        clean, key_cols=("order_id",),
        cat_cols=("customer_zone", "carrier_mode", "delivery_status"),
        business_rules={
            "parcel_weight_kg == -1": clean["parcel_weight_kg"] == -1,
            "delivery_lat == 0.0": clean["delivery_lat"] == 0.0,
        },
        name="cleaned dataset")
