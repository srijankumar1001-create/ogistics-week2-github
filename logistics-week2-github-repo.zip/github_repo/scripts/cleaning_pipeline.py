"""Cleaning pipeline for logistics order/shipment data.

Implements the documented cleaning rules from the Week 2 report:
sentinel-to-missing conversion, deduplication on the business key,
text standardization with an explicit canonical mapping, timestamp
normalization, and SLA-based promise-time fallback. Every rule logs how
many rows/values it touched — no silent changes.

Runnable as-is on the synthetic raw data from data_quality_audit.py.
"""

import numpy as np
import pandas as pd

from data_quality_audit import make_synthetic_raw

# Canonical label maps: explicit and auditable. Unmapped values are
# quarantined for human review, never silently kept.
ZONE_MAP = {"NORTH": "NORTH", "SOUTH": "SOUTH", "EAST": "EAST", "WEST": "WEST"}
CARRIER_MAP = {"VAN": "VAN", "BIKE": "BIKE"}
STATUS_MAP = {"DELIVERED": "DELIVERED", "FAILED": "FAILED",
              "RETURNED": "RETURNED", "UNKNOWN": "UNKNOWN"}


def to_missing_sentinels(df):
    """Convert known placeholder values to proper NaN *before* imputation."""
    df = df.copy()
    n = 0
    # -1 kg is a scale-error sentinel, not a real weight
    mask = df["parcel_weight_kg"] == -1
    n += int(mask.sum())
    df.loc[mask, "parcel_weight_kg"] = np.nan
    # 0.0 latitude is "Null Island": an invalid geocode, not a location
    mask = df["delivery_lat"] == 0.0
    n += int(mask.sum())
    df.loc[mask, "delivery_lat"] = np.nan
    print(f"[sentinels] converted {n} sentinel values to missing")
    return df


def deduplicate(df):
    """Drop duplicate business keys, keeping the earliest complete record."""
    df = df.copy().sort_values("order_ts")
    before = len(df)
    df = df.drop_duplicates(subset="order_id", keep="first")
    print(f"[deduplicate] removed {before - len(df)} duplicate order rows")
    return df


def standardize_text(df, col, mapping, label):
    """Strip, uppercase, and map a text column to canonical labels."""
    df = df.copy()
    raw_vals = df[col].astype(str).str.strip().str.upper()
    mapped = raw_vals.map(mapping)
    n_unmapped = int(mapped.isna().sum() - raw_vals.isna().sum())
    if n_unmapped:
        print(f"[{label}] WARNING: {n_unmapped} unmapped value(s) quarantined: "
              f"{sorted(raw_vals[mapped.isna()].unique())}")
    n_variants = df[col].astype(str).nunique() - raw_vals.nunique()
    df[col] = mapped
    print(f"[{label}] standardized {col}: merged {max(n_variants, 0)} "
          f"case/whitespace variant(s)")
    return df


def normalize_timestamps(df):
    """Parse mixed datetime formats into hub-local naive timestamps."""
    df = df.copy()
    # dayfirst=True handles DD-MM-YYYY; ISO strings parse unambiguously
    df["order_ts"] = pd.to_datetime(df["order_ts"], dayfirst=True,
                                    errors="coerce")
    n_bad = int(df["order_ts"].isna().sum())
    print(f"[timestamps] normalized order_ts ({n_bad} unparsable -> NaT)")
    return df


def promise_time_fallback(df, sla_hours=48):
    """Fill missing promise times with the hub's SLA (order + 48h)."""
    df = df.copy()
    if "promised_ts" not in df.columns:
        df["promised_ts"] = pd.NaT
    df["promised_ts"] = pd.to_datetime(df["promised_ts"], errors="coerce")
    mask = df["promised_ts"].isna() & df["order_ts"].notna()
    df.loc[mask, "promised_ts"] = (df.loc[mask, "order_ts"]
                                   + pd.Timedelta(hours=sla_hours))
    df["promised_imputed"] = mask.astype(int)  # missingness flag
    print(f"[promise_ts] SLA fallback applied to {int(mask.sum())} rows "
          f"(flagged in promised_imputed)")
    return df


def cleaning_pipeline(df):
    """Run the full documented cleaning pipeline, in dependency order."""
    print("--- cleaning pipeline start ---")
    df = to_missing_sentinels(df)   # sentinels first: they poison stats
    df = deduplicate(df)            # then keys: one row per real order
    df = standardize_text(df, "customer_zone", ZONE_MAP, "zones")
    df = standardize_text(df, "carrier_mode", CARRIER_MAP, "carrier")
    df = standardize_text(df, "delivery_status", STATUS_MAP, "status")
    df = normalize_timestamps(df)
    df = promise_time_fallback(df)
    print(f"--- pipeline done: {len(df):,} rows ---")
    return df


if __name__ == "__main__":
    raw = make_synthetic_raw()
    clean = cleaning_pipeline(raw)
    print(clean[["order_id", "customer_zone", "carrier_mode",
                "parcel_weight_kg", "promised_imputed"]].head())
