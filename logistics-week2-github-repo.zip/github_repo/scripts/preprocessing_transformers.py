"""Leakage-safe preprocessing pipeline for logistics modeling.

Assembles imputation, scaling, and encoding into a single scikit-learn
ColumnTransformer wrapped in a Pipeline, with three non-negotiable rules:
  1. Transformers are FIT ON THE TRAINING SPLIT ONLY (medians, scaler
     parameters, category lists learned from train; test only transformed).
  2. Chronological (not random) train/test split — future orders must never
     appear in training for time-adjacent targets.
  3. OneHotEncoder(handle_unknown="ignore") so unseen future categories
     cannot crash production scoring.

Also demonstrates datetime feature engineering and the per-field choice of
transform (z-score vs min-max vs log), each with its rationale.

Runnable as-is on synthetic data.
"""

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def add_datetime_features(df, ts_col="order_ts"):
    """Decompose timestamps into business-meaningful model features."""
    df = df.copy()
    ts = pd.to_datetime(df[ts_col])
    df["dow"] = ts.dt.dayofweek            # weekly seasonality
    df["month"] = ts.dt.month              # monthly/salary-cycle effects
    df["is_weekend"] = (ts.dt.dayofweek >= 5).astype(int)
    df["dispatch_hour_bin"] = pd.cut(
        ts.dt.hour, bins=[0, 6, 12, 18, 24],
        labels=["night", "morning", "afternoon", "evening"],
        include_lowest=True)
    return df


def build_preprocessor(numeric_features, categorical_features):
    """ColumnTransformer: impute + scale numerics, impute + one-hot cats."""
    numeric_pipe = Pipeline(steps=[
        # median: robust to the right-skew of weight/cost fields
        ("imputer", SimpleImputer(strategy="median")),
        # z-score: centers data for regularized models (Ridge penalties
        # assume comparable feature scales)
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        # ignore: unseen future zones/vehicles must not crash scoring
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer(transformers=[
        ("num", numeric_pipe, numeric_features),
        ("cat", categorical_pipe, categorical_features),
    ])


if __name__ == "__main__":
    rng = np.random.default_rng(11)
    n = 3000
    df = pd.DataFrame({
        "order_ts": pd.to_datetime("2026-01-01") + pd.to_timedelta(
            rng.integers(0, 120 * 24, n), unit="h"),
        "customer_zone": rng.choice(["NORTH", "SOUTH", "EAST", "WEST"], n),
        "carrier_mode": rng.choice(["VAN", "BIKE"], n),
        # log-normal-ish cost: many small shipments, few expensive ones
        "shipping_cost_rs": np.abs(rng.normal(220, 140, n)),
        "parcel_weight_kg": np.abs(rng.normal(8, 5, n)),
        "planned_km": np.abs(rng.normal(18, 12, n)),
    })
    # Log transform the skewed cost BEFORE scaling: compresses the tail so a
    # single expensive trip cannot dominate the regression, and makes
    # multiplicative cost effects additive.
    df["log_cost"] = np.log1p(df["shipping_cost_rs"])

    df = add_datetime_features(df)
    # Synthetic target: daily-ish demand proxy with weekly seasonality
    df["orders_next_day"] = (50 + 12 * (df["dow"] < 5)
                             + rng.normal(0, 8, n)).round().astype(int)
    df = df.sort_values("order_ts").reset_index(drop=True)

    numeric = ["parcel_weight_kg", "planned_km", "log_cost",
               "dow", "month", "is_weekend"]
    categorical = ["customer_zone", "carrier_mode", "dispatch_hour_bin"]

    # Chronological split: the last 20% (most recent) is the test set.
    # Random shuffling would leak future orders into training.
    split = int(len(df) * 0.8)
    train, test = df.iloc[:split], df.iloc[split:]
    X_train, y_train = train[numeric + categorical], train["orders_next_day"]
    X_test, y_test = test[numeric + categorical], test["orders_next_day"]
    print(f"train: {train['order_ts'].min().date()} -> "
          f"{train['order_ts'].max().date()} | test: "
          f"{test['order_ts'].min().date()} -> {test['order_ts'].max().date()}")

    # The preprocessor is FIT on train only; test is merely transformed.
    model = Pipeline(steps=[
        ("prep", build_preprocessor(numeric, categorical)),
        ("reg", Ridge(alpha=1.0)),
    ])
    model.fit(X_train, y_train)
    print(f"train R^2: {model.score(X_train, y_train):.3f} | "
          f"test R^2: {model.score(X_test, y_test):.3f}")
    print("No leakage: scaler medians/means and one-hot categories were "
          "learned from the training window alone.")
