"""Data-quality audit for logistics order/shipment data.

Runs five audit dimensions (completeness, uniqueness, validity, consistency,
plausibility) on a raw extract and prints a human-readable report. Reusable:
run it on the raw extract, on each cleaned intermediate, and on real
OMS/TMS/WMS extracts to produce before/after comparisons.

Runnable as-is: generates a small synthetic raw dataset with typical
logistics defects (duplicates, mixed casing, sentinels, outliers).
"""

import numpy as np
import pandas as pd


def make_synthetic_raw(n=2000, seed=42):
    """Build a toy raw extract containing realistic data-quality defects."""
    rng = np.random.default_rng(seed)
    order_ids = [f"ORD-{i:06d}" for i in range(n)]
    df = pd.DataFrame({
        "order_id": order_ids,
        "order_ts": pd.to_datetime("2026-01-01") + pd.to_timedelta(
            rng.integers(0, 90 * 24, n), unit="h"),
        "promised_ts": pd.NaT,  # filled below; ~6% left missing (system gap)
        "customer_zone": rng.choice(
            ["North", "NORTH", "north ", "South", "SOUTH", "East"], n),
        "carrier_mode": rng.choice(["Van", "VAN", "van", "Bike"], n),
        "parcel_weight_kg": np.round(
            np.abs(rng.normal(8, 5, n)), 1),
        "delivery_lat": rng.uniform(12.8, 13.2, n).round(4),
        "delivery_status": rng.choice(
            ["Delivered", "DELIVERED", "delivered ", "Failed", "UNKNOWN"], n),
    })
    # Inject defects -------------------------------------------------------
    df.loc[rng.choice(n, 30, replace=False), "parcel_weight_kg"] = -1  # sentinel
    df.loc[rng.choice(n, 25, replace=False), "delivery_lat"] = 0.0    # invalid
    df.loc[rng.choice(n, 40, replace=False), "parcel_weight_kg"] = np.nan
    df.loc[rng.choice(n, 15, replace=False), "parcel_weight_kg"] = 900  # outlier
    # promise times present for most rows, missing for ~6% (system gap)
    has_promise = rng.choice(n, int(n * 0.94), replace=False)
    df.loc[has_promise, "promised_ts"] = (
        df.loc[has_promise, "order_ts"] + pd.Timedelta(hours=48))
    dupes = df.sample(35, random_state=seed)  # duplicate rows (system retries)
    df = pd.concat([df, dupes], ignore_index=True)
    return df


def audit_dataframe(df, key_cols=("order_id",), cat_cols=(),
                    business_rules=None, name="dataset"):
    """Print a data-quality audit report for ``df`` and return a summary dict."""
    print(f"\n{'=' * 60}\nDATA QUALITY AUDIT — {name} "
          f"({len(df):,} rows x {df.shape[1]} cols)\n{'=' * 60}")
    summary = {}

    # 1. Completeness ------------------------------------------------------
    miss = df.isna().mean().sort_values(ascending=False)
    miss = miss[miss > 0]
    print("\n[Completeness] columns with missing values:")
    for col, frac in miss.items():
        print(f"  {col:<22} {frac:6.2%} missing")
    summary["missing_pct"] = miss.to_dict()

    # 2. Uniqueness --------------------------------------------------------
    dup_rows = df.duplicated().sum()
    dup_keys = df.duplicated(subset=list(key_cols)).sum() if key_cols else 0
    print(f"\n[Uniqueness] exact duplicate rows: {dup_rows:,} | "
          f"duplicate keys {key_cols}: {dup_keys:,}")
    summary.update({"duplicate_rows": int(dup_rows),
                    "duplicate_keys": int(dup_keys)})

    # 3. Validity: business rules ------------------------------------------
    print("\n[Validity] business-rule violations:")
    summary["rule_violations"] = {}
    for rule_name, mask in (business_rules or {}).items():
        n_viol = int(mask.sum())
        print(f"  {rule_name:<40} {n_viol:,} rows")
        summary["rule_violations"][rule_name] = n_viol

    # 4. Consistency: categorical distinct values ---------------------------
    print("\n[Consistency] distinct values per categorical field:")
    for col in cat_cols:
        vals = sorted(df[col].dropna().astype(str).unique())
        print(f"  {col}: {vals}")
        # flag near-duplicates differing only by case/whitespace
        folded = {v.strip().upper() for v in vals}
        if len(folded) < len(vals):
            print(f"    !! {len(vals) - len(folded)} case/whitespace "
                  f"variant(s) detected")

    # 5. Plausibility: IQR outliers -----------------------------------------
    print("\n[Plausibility] IQR outlier counts (numeric fields):")
    summary["iqr_outliers"] = {}
    for col in df.select_dtypes(include="number").columns:
        s = df[col].dropna()
        if len(s) < 4:
            continue
        q1, q3 = s.quantile(0.25), s.quantile(0.75)
        iqr = q3 - q1
        n_out = int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())
        print(f"  {col:<22} {n_out:,} outliers "
              f"(Q1={q1:.2f}, Q3={q3:.2f})")
        summary["iqr_outliers"][col] = n_out

    return summary


if __name__ == "__main__":
    raw = make_synthetic_raw()
    rules = {
        "parcel_weight_kg == -1 (sentinel)":
            raw["parcel_weight_kg"] == -1,
        "delivery_lat == 0.0 (invalid geocode)":
            raw["delivery_lat"] == 0.0,
        "parcel_weight_kg > 500 (over vehicle rating)":
            raw["parcel_weight_kg"] > 500,
    }
    audit_dataframe(raw, key_cols=("order_id",),
                    cat_cols=("customer_zone", "carrier_mode",
                              "delivery_status"),
                    business_rules=rules, name="raw extract")
