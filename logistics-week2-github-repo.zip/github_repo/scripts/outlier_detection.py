"""Outlier detection and treatment for logistics measures.

Three complementary detectors: business-rule bounds (impossible values),
the IQR method (robust to the skew of logistics data), and z-scores on
log-transformed fields. Treatment policy: impossible values are quarantined,
extreme-but-real values are capped (winsorized) with a flag — never
silently deleted, so the row count and the direction of the signal survive.

Runnable as-is: demonstrates detection on a synthetic cycle-time / weight
sample and prints a treatment summary.
"""

import numpy as np
import pandas as pd


def iqr_bounds(s, k=1.5):
    """Return (lower, upper) IQR fences for a series."""
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    return q1 - k * iqr, q3 + k * iqr


def detect_outliers(df, numeric_cols, business_rules=None):
    """Flag outliers per column; returns a boolean DataFrame of flags."""
    flags = pd.DataFrame(False, index=df.index,
                         columns=[f"{c}_outlier" for c in numeric_cols])
    report = {}
    for col in numeric_cols:
        s = df[col].dropna()
        lo, hi = iqr_bounds(s)
        mask = (df[col] < lo) | (df[col] > hi)
        flags[f"{col}_outlier"] = mask.fillna(False)
        report[col] = {"n": int(mask.sum()), "lo": lo, "hi": hi}
    for rule_name, mask in (business_rules or {}).items():
        flags[rule_name] = mask.fillna(False)
        report[rule_name] = {"n": int(mask.sum()), "lo": None, "hi": None}
    return flags, report


def treat_outliers(df, col, cap_quantile=0.995, impossible_mask=None):
    """Cap extreme-but-real values; quarantine impossible ones.

    Why capping: deletion hides the evidence (and biases the sample toward
    well-behaved trips); capping bounds statistical leverage while keeping
    the row and flagging it for sensitivity analysis.
    """
    df = df.copy()
    cap = df[col].quantile(cap_quantile)
    over = df[col] > cap
    df[f"{col}_capped"] = over.astype(int)
    df.loc[over, col] = cap
    n_quarantined = 0
    if impossible_mask is not None:
        n_quarantined = int(impossible_mask.sum())
        df.loc[impossible_mask, f"{col}_quarantined"] = 1
    print(f"[treat] {col}: capped {int(over.sum())} value(s) at "
          f"{cap_quantile:.1%} quantile ({cap:.2f}); "
          f"quarantined {n_quarantined} impossible value(s)")
    return df


def zscore_on_log(df, col, threshold=3.0):
    """Secondary check: z-scores on the log transform (for skewed costs)."""
    s = np.log1p(df[col].dropna())
    z = (s - s.mean()) / s.std()
    mask = pd.Series(False, index=df.index)
    mask.loc[z[abs(z) > threshold].index] = True
    print(f"[zscore-log] {col}: {int(mask.sum())} value(s) beyond "
          f"|z| > {threshold} on log scale")
    return mask


if __name__ == "__main__":
    rng = np.random.default_rng(7)
    n = 5000
    df = pd.DataFrame({
        # right-skewed cycle times (hours), with injected extremes
        "cycle_hours": np.abs(rng.normal(30, 18, n)),
        "parcel_weight_kg": np.abs(rng.normal(8, 5, n)),
        "shipping_cost_rs": np.abs(rng.normal(220, 140, n)),
    })
    df.loc[rng.choice(n, 20, replace=False), "cycle_hours"] = \
        rng.uniform(400, 960, 20)          # unclosed trips: impossible-ish
    df.loc[rng.choice(n, 10, replace=False), "parcel_weight_kg"] = 900
    df.loc[rng.choice(n, 5, replace=False), "shipping_cost_rs"] = -50  # invalid

    business_rules = {
        "cycle_hours_impossible": df["cycle_hours"] > 24 * 14,  # >14 days
        "shipping_cost_negative": df["shipping_cost_rs"] < 0,
    }
    flags, report = detect_outliers(
        df, ["cycle_hours", "parcel_weight_kg", "shipping_cost_rs"],
        business_rules)
    for name, r in report.items():
        print(f"  {name:<28} outliers/violations: {r['n']}")

    df = treat_outliers(df, "parcel_weight_kg",
                        impossible_mask=df["parcel_weight_kg"] > 500)
    df = treat_outliers(df, "cycle_hours",
                        impossible_mask=business_rules["cycle_hours_impossible"])
    zscore_on_log(df, "shipping_cost_rs")

    print("\nEffect of treatment on distribution shape:")
    print(df[["cycle_hours", "parcel_weight_kg"]].describe()
          .loc[["mean", "std", "max"]].round(2))
