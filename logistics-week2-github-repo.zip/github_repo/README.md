# Week 2 — Data Collection, Cleaning, and Preprocessing for Logistics Analysis

Preprocessing pipeline for the regional distribution hub project (companion to the Week 1 strategic planning report): **optimizing last-mile delivery operations and inventory planning for a regional distribution hub serving urban and semi-urban customers.**

This repository simulates data collection from a public logistics-style order/shipment extract, audits its data quality, and builds a documented, reproducible cleaning and preprocessing pipeline in Python. Every cleaning decision is logged — no silent imputation, no invisible row deletions.

## What's inside

| Script | What it does |
|---|---|
| `scripts/data_quality_audit.py` | Reusable `audit_dataframe()` covering five dimensions — completeness, uniqueness, validity, consistency, plausibility (IQR outliers). Generates a synthetic raw extract with realistic defects and prints the audit report. |
| `scripts/cleaning_pipeline.py` | Documented cleaning pipeline: sentinel-to-missing conversion, deduplication on the business key, text standardization via explicit canonical maps, timestamp normalization, and SLA-based promise-time fallback with a missingness flag. |
| `scripts/outlier_detection.py` | IQR + z-score (on log scale) + business-rule outlier detection; treatment policy of capping extreme-but-real values and quarantining impossible ones, each with a flag. |
| `scripts/preprocessing_transformers.py` | Leakage-safe scikit-learn `ColumnTransformer` (`SimpleImputer` + `StandardScaler` / `OneHotEncoder`) wrapped in a `Pipeline`, fitted on a chronological train split only; includes datetime feature engineering and log transforms for skewed fields. |
| `scripts/quality_before_after.py` | Re-runs the audit on raw vs. cleaned data and prints the before/after comparison table from the report — a computed artifact, never hand-edited. |

Each script runs standalone (`python3 scripts/<name>.py`) on small synthetic data with fixed seeds, so the full pipeline can be demonstrated without access to the real extracts. Point the loading lines at the real OMS/TMS/WMS exports to run on production data.

## Full report

See `Week2_Logistics_Data_Preprocessing_Report.docx` for the complete Week 2 report: data collection simulation, defect catalogue with methodological justifications, missing-value rules, outlier policy, normalization choices, leakage-safe pipeline design, before/after comparison, and reflection on how data quality propagates into analytics and decisions.

## Tech stack

Python 3 · pandas · numpy · scikit-learn · matplotlib
